# Me => https://twitter.com/maxtuno

if __name__ == '__main__':

    # data => http://www.cs.utsa.edu/~wagner/CS3343/ss/ss.html
    target = 2618000
    universe = [10207, 11296, 11587, 12426, 12823, 13174, 15859, 15899, 16006, 16489, 16493, 17285, 18091, 18673, 19133, 19560, 20346, 20768, 20949, 22800, 22857, 23206, 23547, 24354, 24927, 25778, 27320, 27516, 29356, 30849, 32221, 32233, 32447, 32609, 32644, 33346, 34591, 35506, 36451, 37398, 38235, 40590, 41208, 42990, 44137, 44383, 44436, 44484, 46011, 46177, 46205, 46660, 47870, 48665, 50851, 51656, 52005, 53697, 54719, 56623, 56894, 57124, 59791, 60085, 60313, 62182, 64244, 65648, 66814, 66898, 67950, 68502, 69640, 70523, 72041, 73413, 73454, 76055, 76652, 77123, 77600, 77701, 78465, 81628, 81866, 82388, 84351, 84622, 87382, 88730, 90015, 90365, 90435, 91420, 91977, 94664, 96331, 97454, 99313, 99971, ]

    print('target             : {}'.format(target))
    print('universe           : {}'.format(universe))

    solutions = {}
    with open('solutions.txt') as f:
        for solution in f.readlines():
            solution = solution.replace(str(target), '').replace('\n', '')
            if solution:
                subset = eval(solution)
                print(100 * '-')
                print('subset             : {}'.format(subset))
                print('sum(subset)        : {}'.format(sum(subset)))
                print('len(subset)        : {}'.format(len(subset)))
                print('repeated elements  : {}'.format(len(subset) - len(set(subset))))
                print('is subset?         : {}'.format(len([s for s in subset if s in universe]) == len(subset)))
                print('is solution?       : {}'.format(sum(subset) == target))
                print('is repeated?       : {}'.format(solutions.get(solution, 0) > 0))
                if not solutions.get(solution, False):
                    solutions[solution] = 1
                else:
                    solutions[solution] += 1

    total_solutions = 0
    for k, v in solutions.items():
        total_solutions += v
    print(100 * '=')
    print('repeated solutions : {}'.format(total_solutions - len(solutions)))
    print('total solutions    : {}'.format(total_solutions))